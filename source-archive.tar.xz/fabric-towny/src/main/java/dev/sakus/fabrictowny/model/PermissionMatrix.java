package dev.sakus.fabrictowny.model;
import java.util.EnumMap;
import java.util.Map;
public final class PermissionMatrix {
  public Map<PermissionGroup, Map<PermissionAction, Boolean>> values = new EnumMap<>(PermissionGroup.class);
  public PermissionMatrix() { resetDefaults(); }
  public void resetDefaults() {
    values.clear();
    for (PermissionGroup g : PermissionGroup.values()) {
      EnumMap<PermissionAction, Boolean> actions = new EnumMap<>(PermissionAction.class);
      for (PermissionAction a : PermissionAction.values()) actions.put(a, g == PermissionGroup.RESIDENT);
      values.put(g, actions);
    }
  }
  public boolean allows(PermissionGroup group, PermissionAction action) {
    return values.getOrDefault(group, Map.of()).getOrDefault(action, false);
  }
  public void set(PermissionGroup group, PermissionAction action, boolean value) {
    values.computeIfAbsent(group, ignored -> new EnumMap<>(PermissionAction.class)).put(action, value);
  }
  public void setAll(boolean value) { for (var g : PermissionGroup.values()) for (var a : PermissionAction.values()) set(g,a,value); }
}
