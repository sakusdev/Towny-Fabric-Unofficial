package dev.sakus.fabrictowny.protection;
import dev.sakus.fabrictowny.model.*;
import dev.sakus.fabrictowny.service.TownyService;
import java.util.UUID;
public final class ProtectionEngine {
  private final TownyService service;
  public ProtectionEngine(TownyService service){this.service=service;}
  public boolean allowed(UUID actor,String key,PermissionAction action,boolean admin){
    if(admin)return true; TownBlock block=service.store().data().blocks.get(key); if(block==null)return service.config().wildernessBuild;
    Town owner=service.store().data().towns.get(block.townId); if(owner==null)return true;
    if(block.owner!=null&&block.owner.equals(actor))return true;
    PermissionGroup group=service.group(owner,actor);
    return block.permissions.allows(group,action) || owner.permissions.allows(group,action);
  }
  public boolean pvp(UUID attacker,UUID victim,String key,boolean admin){
    if(admin)return true;TownBlock b=service.store().data().blocks.get(key);if(b==null)return true;Town t=service.store().data().towns.get(b.townId);if(t==null)return true;
    if(!service.config().allowFriendlyFire){var a=service.town(attacker).orElse(null);var v=service.town(victim).orElse(null);if(a!=null&&v!=null&&(a.id.equals(v.id)||(a.nationId!=null&&a.nationId.equals(v.nationId))))return false;}
    return b.pvp||t.pvp;
  }
}
