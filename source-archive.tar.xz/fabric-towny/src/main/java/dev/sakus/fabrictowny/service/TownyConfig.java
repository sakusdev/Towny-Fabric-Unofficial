package dev.sakus.fabrictowny.service;
public final class TownyConfig {
  public double townCreationCost=0, nationCreationCost=0, claimCost=0, outpostCost=0;
  public int baseTownBlocks=8, blocksPerResident=8, maxOutposts=3;
  public long inviteLifetimeMillis=300_000, newDayIntervalMillis=86_400_000;
  public boolean requireAdjacentClaims=true, allowFriendlyFire=false, wildernessBuild=true;
}
