package dev.sakus.fabrictowny.protection;
import dev.sakus.fabrictowny.ClaimKey;
import dev.sakus.fabrictowny.model.PermissionAction;
import net.fabricmc.fabric.api.event.player.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
public final class ProtectionHooks {
 private ProtectionHooks(){}
 public static void register(ProtectionEngine e){
  PlayerBlockBreakEvents.BEFORE.register((w,p,pos,state,be)->check(e,p,ClaimKey.of(w,pos),PermissionAction.DESTROY));
  AttackBlockCallback.EVENT.register((p,w,h,pos,d)->{if(w.isClient()||!(p instanceof ServerPlayerEntity sp))return ActionResult.PASS;return check(e,sp,ClaimKey.of(sp.getServerWorld(),pos),PermissionAction.DESTROY)?ActionResult.PASS:ActionResult.FAIL;});
  UseBlockCallback.EVENT.register((p,w,h,hit)->{if(w.isClient()||!(p instanceof ServerPlayerEntity sp))return ActionResult.PASS;return check(e,sp,ClaimKey.of(sp.getServerWorld(),hit.getBlockPos()),PermissionAction.SWITCH)?ActionResult.PASS:ActionResult.FAIL;});
  UseItemCallback.EVENT.register((p,w,h)->{if(w.isClient()||!(p instanceof ServerPlayerEntity sp))return net.minecraft.util.TypedActionResult.pass(p.getStackInHand(h));boolean ok=check(e,sp,ClaimKey.of(sp.getServerWorld(),sp.getBlockPos()),PermissionAction.ITEM_USE);return ok?net.minecraft.util.TypedActionResult.pass(p.getStackInHand(h)):net.minecraft.util.TypedActionResult.fail(p.getStackInHand(h));});
 }
 private static boolean check(ProtectionEngine e,ServerPlayerEntity p,String key,PermissionAction a){boolean ok=e.allowed(p.getUuid(),key,a,p.hasPermissionLevel(2));if(!ok)p.sendMessage(Text.literal("この土地ではその操作は許可されていません。"),true);return ok;}
}
