package dev.sakus.fabrictowny.service;
import dev.sakus.fabrictowny.economy.EconomyProvider;
import dev.sakus.fabrictowny.model.*;
import dev.sakus.fabrictowny.storage.TownyStore;
import java.util.*;
public final class TownyService {
  private final TownyStore store; private final EconomyProvider economy; private final TownyConfig config;
  public TownyService(TownyStore store,EconomyProvider economy,TownyConfig config){this.store=store;this.economy=economy;this.config=config;}
  public TownyStore store(){return store;} public TownyConfig config(){return config;} public EconomyProvider economy(){return economy;}
  public Resident resident(UUID id,String name){var r=store.data().residents.computeIfAbsent(id,k->new Resident(id,name));r.lastKnownName=name;r.lastOnline=System.currentTimeMillis();return r;}
  public Optional<Town> town(UUID player){var r=store.data().residents.get(player);return r==null||r.townId==null?Optional.empty():Optional.ofNullable(store.data().towns.get(r.townId));}
  public Optional<Town> townByName(String name){return store.data().towns.values().stream().filter(t->t.name.equalsIgnoreCase(name)).findFirst();}
  public Optional<Nation> nationByName(String name){return store.data().nations.values().stream().filter(n->n.name.equalsIgnoreCase(name)).findFirst();}
  public Optional<TownBlock> block(String key){return Optional.ofNullable(store.data().blocks.get(key));}
  public Town createTown(UUID player,String playerName,String name,String homeKey){
    if(town(player).isPresent())throw new IllegalStateException("すでに町に所属しています。"); if(townByName(name).isPresent())throw new IllegalStateException("その町名は使用済みです。");
    if(!economy.withdraw(player,config.townCreationCost,"town-create"))throw new IllegalStateException("町作成費用が不足しています。");
    String id=slug(name);Town t=new Town(id,name,player);t.homeBlock=homeKey;t.blocks.add(homeKey);store.data().towns.put(id,t);store.data().blocks.put(homeKey,new TownBlock(homeKey,id));resident(player,playerName).townId=id;store.save();return t;
  }
  public void deleteTown(Town town){ if(town.nationId!=null){var n=store.data().nations.get(town.nationId);if(n!=null){n.towns.remove(town.id);if(n.capitalTownId.equals(town.id))deleteNation(n);}} for(UUID id:town.residents){var r=store.data().residents.get(id);if(r!=null)r.townId=null;} town.blocks.forEach(store.data().blocks::remove);store.data().towns.remove(town.id);store.save(); }
  public void deleteNation(Nation nation){for(String tid:nation.towns){var t=store.data().towns.get(tid);if(t!=null)t.nationId=null;}store.data().nations.remove(nation.id);store.save();}
  public boolean canClaim(Town t){return t.blocks.size()<config.baseTownBlocks+t.residents.size()*config.blocksPerResident;}
  public void claim(Town t,String key,boolean outpost){if(store.data().blocks.containsKey(key))throw new IllegalStateException("領有済みです。");if(!canClaim(t))throw new IllegalStateException("領有可能数を超えています。");if(!outpost&&config.requireAdjacentClaims&&!adjacent(t,key))throw new IllegalStateException("既存領地に隣接していません。");TownBlock b=new TownBlock(key,t.id);b.outpost=outpost;t.blocks.add(key);store.data().blocks.put(key,b);store.save();}
  public void unclaim(Town t,String key){TownBlock b=store.data().blocks.get(key);if(b==null||!t.id.equals(b.townId))throw new IllegalStateException("自分の町の領地ではありません。");if(key.equals(t.homeBlock))throw new IllegalStateException("ホームブロックは解除できません。");t.blocks.remove(key);store.data().blocks.remove(key);store.save();}
  public Nation createNation(Town capital,String name){if(capital.nationId!=null)throw new IllegalStateException("すでに国家所属です。");if(nationByName(name).isPresent())throw new IllegalStateException("その国家名は使用済みです。");String id=slug(name);Nation n=new Nation(id,name,capital.id);store.data().nations.put(id,n);capital.nationId=id;store.save();return n;}
  public void joinTown(UUID player,String playerName,Town town){if(town(player).isPresent())throw new IllegalStateException("すでに町に所属しています。");town.residents.add(player);resident(player,playerName).townId=town.id;store.save();}
  public void leaveTown(UUID player){Town t=town(player).orElseThrow(()->new IllegalStateException("町に所属していません。"));if(t.mayor.equals(player))throw new IllegalStateException("町長は辞任または町削除が必要です。");t.residents.remove(player);var r=store.data().residents.get(player);if(r!=null)r.townId=null;for(var b:store.data().blocks.values())if(player.equals(b.owner))b.owner=null;store.save();}
  public PermissionGroup group(Town ownerTown,UUID actor){var at=town(actor).orElse(null);if(at!=null&&at.id.equals(ownerTown.id))return PermissionGroup.RESIDENT;if(ownerTown.nationId!=null&&at!=null&&ownerTown.nationId.equals(at.nationId))return PermissionGroup.NATION;if(ownerTown.nationId!=null&&at!=null&&at.nationId!=null){var n=store.data().nations.get(ownerTown.nationId);if(n!=null&&n.allies.contains(at.nationId))return PermissionGroup.ALLY;}return PermissionGroup.OUTSIDER;}
  private boolean adjacent(Town t,String key){var p=parse(key);if(p==null)return false;for(int[]d:new int[][]{{1,0},{-1,0},{0,1},{0,-1}})if(t.blocks.contains(p[0]+":"+(Integer.parseInt(p[1])+d[0])+":"+(Integer.parseInt(p[2])+d[1])))return true;return false;}
  private static String[] parse(String key){int a=key.lastIndexOf(':');int b=key.lastIndexOf(':',a-1);return a<0||b<0?null:new String[]{key.substring(0,b),key.substring(b+1,a),key.substring(a+1)};}
  private static String slug(String name){return name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_\\-]","_")+"_"+Integer.toUnsignedString(name.hashCode(),36);}
}
