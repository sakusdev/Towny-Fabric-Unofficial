package dev.sakus.fabrictowny.economy;
import dev.sakus.fabrictowny.storage.TownyStore;
import java.util.UUID;
public final class InternalEconomy implements EconomyProvider {
  private final TownyStore store;
  public InternalEconomy(TownyStore store){this.store=store;}
  public double balance(UUID id){var r=store.data().residents.get(id); return r==null?0:r.balance;}
  public boolean withdraw(UUID id,double amount,String reason){if(amount<0)return false;var r=store.data().residents.get(id);if(r==null||r.balance+1e-8<amount)return false;r.balance-=amount;return true;}
  public void deposit(UUID id,double amount,String reason){if(amount<=0)return;var r=store.data().residents.get(id);if(r!=null)r.balance+=amount;}
  public String format(double amount){return String.format("¥%,.0f",amount);}
}
