package dev.sakus.fabrictowny;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
public final class ClaimKey { private ClaimKey(){} public static String of(ServerWorld w,BlockPos p){return w.getRegistryKey().getValue()+":"+(p.getX()>>4)+":"+(p.getZ()>>4);} }
